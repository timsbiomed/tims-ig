# sample-ig
A sample, template-driven implementation guide that provides a starting environment to use a base for defining new IGs
